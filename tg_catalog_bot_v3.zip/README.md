# Telegram Catalog Bot V3

通用商品目录/询价机器人模板，可用于合法商品或服务。
本版本不包含烟草交易、收款、发货或规避平台监管功能。

## V3 功能
- /start 首页
- 六宫格分类
- 商品搜索
- 商品详情
- 用户询价
- 管理员后台
- 添加/修改/删除商品
- 上架/下架
- 修改价格与库存
- 查看询价
- SQLite 数据库

## 安装
Python 3.11+

```bash
pip install -r requirements.txt
cp .env.example .env
```

在 `.env` 填：
- BOT_TOKEN：BotFather 创建机器人的 Token
- ADMIN_IDS：你的 Telegram 数字用户 ID，多个用逗号分隔

运行：
```bash
python bot.py
```
